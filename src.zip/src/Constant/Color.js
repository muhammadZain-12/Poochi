const Colors = {
    primary: '#00AEEF',
    main : "#fec033",
    secondary: '#21409A',
    black: '#000',
    gray: "gray",
    white: '#fff',
    emailBtnColor: '#00AEEF',
    fbColor: '#21409A',
    googleBtnColor: '#E02A31',
    phoneNumColor: '#311432',
    fontColor: '#21409A',
    drawerContainerColor: '#1A1A1A',
    onlineStatusColor: "#054d20",
    red: 'red',
    green:"#19A20D",
    input:"#F5F9FE",
    buttonColor:"#19A20D"

};
export default Colors;