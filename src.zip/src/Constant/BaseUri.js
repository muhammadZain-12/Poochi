export const Base_Uri = "https://fine-pear-mite-yoke.cyclic.cloud/api/"

// export const Base_Uri = "http://192.168.100.84:5000/api/"