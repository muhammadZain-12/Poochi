import { createContext } from "react";

const ScheduleRideContext = createContext()

export default ScheduleRideContext