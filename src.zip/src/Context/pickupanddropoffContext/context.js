import { createContext } from "react";


const ChooseLocationContext = createContext()

export default ChooseLocationContext