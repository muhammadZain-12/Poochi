import { createContext } from "react";


const LocationContext = createContext()

export default LocationContext