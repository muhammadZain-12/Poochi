import { createContext } from "react";


const BookingContext = createContext()

export default BookingContext