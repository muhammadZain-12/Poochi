import { createContext } from "react";


const cardDetailsContext = createContext()

export default cardDetailsContext