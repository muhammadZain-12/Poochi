import { createContext } from "react";


const ClaimContext = createContext()

export default ClaimContext