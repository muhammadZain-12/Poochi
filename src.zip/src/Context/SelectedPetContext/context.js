import { createContext } from "react";


const SelectedPetContext = createContext()

export default SelectedPetContext